const express = require('express');
const router = express.Router();
const Chat = require('../models/Chat');
const { protect, adminOnly } = require('../middleware/authMiddleware');

// GET /api/chat/my — get user's chat
router.get('/my', protect, async (req, res) => {
  try {
    let chat = await Chat.findOne({ user: req.user._id }).populate('user', 'name email');
    if (!chat) {
      chat = await Chat.create({ user: req.user._id, messages: [] });
    }
    res.json(chat);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST /api/chat/message — send a message
router.post('/message', protect, async (req, res) => {
  try {
    const { text } = req.body;
    let chat = await Chat.findOne({ user: req.user._id });
    if (!chat) {
      chat = await Chat.create({ user: req.user._id, messages: [] });
    }
    chat.messages.push({
      sender: req.user._id,
      senderName: req.user.name,
      text,
      isAdmin: req.user.role === 'admin',
    });
    await chat.save();
    res.json(chat);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/chat/all — all chats (admin)
router.get('/all', protect, adminOnly, async (req, res) => {
  try {
    const chats = await Chat.find({ isOpen: true })
      .populate('user', 'name email')
      .sort({ updatedAt: -1 });
    res.json(chats);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST /api/chat/:chatId/reply — admin reply
router.post('/:chatId/reply', protect, adminOnly, async (req, res) => {
  try {
    const chat = await Chat.findById(req.params.chatId);
    if (!chat) return res.status(404).json({ message: 'Chat not found' });
    chat.messages.push({
      sender: req.user._id,
      senderName: req.user.name,
      text: req.body.text,
      isAdmin: true,
    });
    await chat.save();
    res.json(chat);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
