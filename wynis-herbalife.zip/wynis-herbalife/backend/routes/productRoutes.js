const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const { protect, adminOnly } = require('../middleware/authMiddleware');

// GET /api/products — all products (with search & filter)
router.get('/', async (req, res) => {
  try {
    const { search, category, minPrice, maxPrice, sort } = req.query;
    let query = { isActive: true };

    if (search) query.name = { $regex: search, $options: 'i' };
    if (category) query.category = category;
    if (minPrice || maxPrice) {
      query.price = {};
      if (minPrice) query.price.$gte = Number(minPrice);
      if (maxPrice) query.price.$lte = Number(maxPrice);
    }

    let sortOption = {};
    if (sort === 'price-asc') sortOption = { price: 1 };
    else if (sort === 'price-desc') sortOption = { price: -1 };
    else if (sort === 'rating') sortOption = { rating: -1 };
    else sortOption = { createdAt: -1 };

    const products = await Product.find(query).sort(sortOption);
    res.json(products);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/products/:id
router.get('/:id', async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ message: 'Product not found' });
    res.json(product);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST /api/products — Admin only
router.post('/', protect, adminOnly, async (req, res) => {
  try {
    const product = await Product.create(req.body);
    res.status(201).json(product);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// PUT /api/products/:id — Admin only
router.put('/:id', protect, adminOnly, async (req, res) => {
  try {
    const product = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(product);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// DELETE /api/products/:id — Admin only
router.delete('/:id', protect, adminOnly, async (req, res) => {
  try {
    await Product.findByIdAndUpdate(req.params.id, { isActive: false });
    res.json({ message: 'Product removed' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Seed sample products
router.post('/seed/data', async (req, res) => {
  try {
    await Product.deleteMany({});
    const products = [
      { name: 'Formula 1 Nutritional Shake Mix', description: 'A nutritious meal replacement shake with essential vitamins and minerals. Available in chocolate, vanilla, and strawberry flavors.', price: 1299, originalPrice: 1599, category: 'weight-management', rating: 4.8, reviews: 245, tags: ['bestseller', 'protein'], image: 'https://via.placeholder.com/300x300/1a7a52/ffffff?text=Formula+1' },
      { name: 'Herbalife Protein Drink Mix', description: 'High-protein drink mix to support muscle building and recovery after workouts.', price: 1599, originalPrice: 1999, category: 'sports', rating: 4.7, reviews: 189, tags: ['protein', 'gym'], image: 'https://via.placeholder.com/300x300/0a5c3a/ffffff?text=Protein+Mix' },
      { name: 'Cell Activator', description: 'Supports nutrient absorption and helps the body convert food into energy at the cellular level.', price: 899, originalPrice: 1099, category: 'nutrition', rating: 4.6, reviews: 130, tags: ['energy', 'absorption'], image: 'https://via.placeholder.com/300x300/2d9e6b/ffffff?text=Cell+Activator' },
      { name: 'Herbal Aloe Concentrate', description: 'Refreshing aloe vera drink concentrate that supports digestive health and hydration.', price: 699, originalPrice: 899, category: 'nutrition', rating: 4.5, reviews: 98, tags: ['aloe', 'digestive'], image: 'https://via.placeholder.com/300x300/1a7a52/ffffff?text=Aloe+Vera' },
      { name: 'Liftoff Energy Drink', description: 'Effervescent energy drink tablet with caffeine, taurine, and B vitamins for instant energy.', price: 549, originalPrice: 699, category: 'energy', rating: 4.4, reviews: 212, tags: ['energy', 'caffeine'], image: 'https://via.placeholder.com/300x300/0a5c3a/ffffff?text=Liftoff' },
      { name: 'Herbalife 24 Rebuild Strength', description: 'Post-workout protein supplement with 25g protein per serving for muscle recovery.', price: 2199, originalPrice: 2599, category: 'sports', rating: 4.9, reviews: 76, tags: ['recovery', 'protein', 'bestseller'], image: 'https://via.placeholder.com/300x300/2d9e6b/ffffff?text=Rebuild' },
    ];
    const created = await Product.insertMany(products);
    res.json({ message: `${created.length} products seeded!`, products: created });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
