const Chat = require('../models/Chat');

module.exports = (io) => {
  const activeUsers = new Map(); // userId -> socketId

  io.on('connection', (socket) => {
    console.log(`🔌 Socket connected: ${socket.id}`);

    // User joins their chat room
    socket.on('join_chat', ({ userId }) => {
      socket.join(userId);
      activeUsers.set(userId, socket.id);
      console.log(`👤 User ${userId} joined chat room`);
    });

    // Admin joins a user's chat room
    socket.on('admin_join', ({ userId }) => {
      socket.join(userId);
      console.log(`🛡 Admin joined room for user: ${userId}`);
    });

    // User sends a message
    socket.on('send_message', async ({ userId, text, senderName, isAdmin }) => {
      try {
        let chat = await Chat.findOne({ user: userId });
        if (!chat) {
          chat = new Chat({ user: userId, messages: [] });
        }
        const newMsg = {
          senderName,
          text,
          isAdmin: isAdmin || false,
          createdAt: new Date(),
        };
        chat.messages.push(newMsg);
        await chat.save();

        // Emit to room (user + any admin watching)
        io.to(userId).emit('receive_message', {
          ...newMsg,
          _id: chat.messages[chat.messages.length - 1]._id,
        });

        // Notify admin dashboard of new message if not from admin
        if (!isAdmin) {
          socket.broadcast.emit('new_user_message', { userId, senderName, text });
        }
      } catch (err) {
        socket.emit('chat_error', { message: 'Message failed: ' + err.message });
      }
    });

    // Typing indicators
    socket.on('typing', ({ userId, isAdmin }) => {
      socket.to(userId).emit('user_typing', { isAdmin });
    });

    socket.on('stop_typing', ({ userId }) => {
      socket.to(userId).emit('user_stop_typing');
    });

    socket.on('disconnect', () => {
      activeUsers.forEach((socketId, userId) => {
        if (socketId === socket.id) activeUsers.delete(userId);
      });
      console.log(`❌ Socket disconnected: ${socket.id}`);
    });
  });
};
