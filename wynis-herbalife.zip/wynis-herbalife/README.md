# 🌿 Wynis Herbalife — MERN E-commerce App

Full-stack MERN e-commerce platform for Herbalife products.

## ✅ Features
- JWT Authentication (Login / Signup)
- Product Listing with Search & Filter
- Add to Cart & Quantity Management
- Checkout with Address Form
- Payment: UPI + Razorpay Integration
- Real-time Chat (Socket.io)
- Order History & Tracking
- Contact: 📞 9532925275

---

## 🗂 Project Structure
```
wynis-herbalife/
├── backend/          ← Node.js + Express + MongoDB
│   ├── models/       (User, Product, Order, Chat)
│   ├── routes/       (auth, products, cart, orders, payment, chat)
│   ├── middleware/   (JWT auth)
│   ├── socket/       (Socket.io real-time chat)
│   └── server.js
└── frontend/         ← React.js
    └── src/
        ├── pages/    (Home, Login, Signup, Products, Cart, Checkout, Orders)
        ├── components/ (Navbar, ChatWidget)
        ├── context/  (AuthContext, CartContext)
        └── utils/    (api.js — all axios calls)
```

---

## 🚀 Quick Setup

### 1. Backend Setup
```bash
cd backend
npm install
cp .env.example .env
# Fill in .env with your MongoDB URI and Razorpay keys
npm run dev
```

### 2. Frontend Setup
```bash
cd frontend
npm install
npm start
```

### 3. Seed Products (optional)
```
POST http://localhost:5000/api/products/seed/data
```

---

## 🔑 Environment Variables (backend/.env)

| Variable | Description |
|---|---|
| `MONGO_URI` | MongoDB connection string |
| `JWT_SECRET` | Any secret string |
| `RAZORPAY_KEY_ID` | From Razorpay Dashboard |
| `RAZORPAY_KEY_SECRET` | From Razorpay Dashboard |
| `CLIENT_URL` | Frontend URL (http://localhost:3000) |

---

## 💳 Razorpay Setup
1. Sign up at [razorpay.com](https://razorpay.com)
2. Go to Settings → API Keys → Generate Key
3. Copy Key ID and Key Secret to `.env`

---

## 📡 API Endpoints

### Auth
| Method | URL | Description |
|---|---|---|
| POST | `/api/auth/register` | Register user |
| POST | `/api/auth/login` | Login user |
| GET | `/api/auth/profile` | Get profile (auth) |

### Products
| Method | URL | Description |
|---|---|---|
| GET | `/api/products` | Get all products |
| GET | `/api/products/:id` | Get single product |
| POST | `/api/products/seed/data` | Seed sample products |

### Cart
| Method | URL | Description |
|---|---|---|
| GET | `/api/cart` | Get cart (auth) |
| POST | `/api/cart/add` | Add to cart (auth) |
| PUT | `/api/cart/update` | Update qty (auth) |
| DELETE | `/api/cart/remove/:id` | Remove item (auth) |

### Orders
| Method | URL | Description |
|---|---|---|
| POST | `/api/orders` | Place order (auth) |
| GET | `/api/orders/my` | My orders (auth) |
| GET | `/api/orders/:id` | Order detail (auth) |
| PUT | `/api/orders/:id/pay` | Mark paid (auth) |

### Payment
| Method | URL | Description |
|---|---|---|
| POST | `/api/payment/create-order` | Create Razorpay order |
| POST | `/api/payment/verify` | Verify payment |

### Chat
| Method | URL | Description |
|---|---|---|
| GET | `/api/chat/my` | Get chat history (auth) |
| POST | `/api/chat/message` | Send message (auth) |

---

## 🔌 Socket.io Events

| Event | Direction | Description |
|---|---|---|
| `join_chat` | Client → Server | Join user's chat room |
| `send_message` | Client → Server | Send a message |
| `receive_message` | Server → Client | New message received |
| `user_typing` | Client → Server | Typing indicator |
| `stop_typing` | Client → Server | Stop typing |

---

## 📞 Contact
**Wynis Herbalife Support:** 9532925275
