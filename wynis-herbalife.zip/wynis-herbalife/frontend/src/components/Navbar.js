import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import toast from 'react-hot-toast';

const styles = {
  nav: { background: '#0a5c3a', padding: '0 2rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: '64px', position: 'sticky', top: 0, zIndex: 100, boxShadow: '0 2px 10px rgba(0,0,0,0.15)' },
  logo: { color: '#7effc2', fontSize: '1.3rem', fontWeight: 700, textDecoration: 'none', fontFamily: 'Georgia, serif' },
  logoSub: { color: 'rgba(255,255,255,0.7)', fontSize: '0.7rem', display: 'block', letterSpacing: '1px' },
  links: { display: 'flex', alignItems: 'center', gap: '1rem' },
  link: { color: 'rgba(255,255,255,0.85)', textDecoration: 'none', fontSize: '0.9rem', padding: '6px 12px', borderRadius: '6px', transition: 'background 0.2s' },
  cartBtn: { position: 'relative', color: '#fff', textDecoration: 'none', background: 'rgba(255,255,255,0.15)', padding: '6px 14px', borderRadius: '20px', fontSize: '0.9rem', display: 'flex', alignItems: 'center', gap: '6px' },
  badge: { background: '#ff6b6b', color: '#fff', borderRadius: '50%', width: '18px', height: '18px', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: '11px', fontWeight: 700 },
  logoutBtn: { background: 'rgba(255,255,255,0.15)', color: '#fff', border: '1px solid rgba(255,255,255,0.3)', padding: '6px 14px', borderRadius: '6px', cursor: 'pointer', fontSize: '0.9rem' },
};

export default function Navbar() {
  const { user, logoutUser } = useAuth();
  const { totalItems } = useCart();
  const navigate = useNavigate();

  const handleLogout = () => {
    logoutUser();
    toast.success('Logged out successfully');
    navigate('/');
  };

  return (
    <nav style={styles.nav}>
      <Link to="/" style={styles.logo}>
        🌿 Wynis
        <span style={styles.logoSub}>HERBALIFE</span>
      </Link>
      <div style={styles.links}>
        <Link to="/products" style={styles.link}>Products</Link>
        {user ? (
          <>
            <Link to="/orders" style={styles.link}>My Orders</Link>
            <Link to="/cart" style={styles.cartBtn}>
              🛒 Cart {totalItems > 0 && <span style={styles.badge}>{totalItems}</span>}
            </Link>
            <span style={{ color: 'rgba(255,255,255,0.6)', fontSize: '0.85rem' }}>Hi, {user.name?.split(' ')[0]}</span>
            <button onClick={handleLogout} style={styles.logoutBtn}>Logout</button>
          </>
        ) : (
          <>
            <Link to="/login" style={styles.link}>Login</Link>
            <Link to="/signup" style={{ ...styles.link, background: '#7effc2', color: '#0a5c3a', fontWeight: 600 }}>Sign Up</Link>
          </>
        )}
      </div>
    </nav>
  );
}
