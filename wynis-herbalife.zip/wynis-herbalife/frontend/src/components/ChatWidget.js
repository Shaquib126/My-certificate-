import React, { useState, useEffect, useRef } from 'react';
import { io } from 'socket.io-client';
import { useAuth } from '../context/AuthContext';
import { getMyChat } from '../utils/api';

const SOCKET_URL = process.env.REACT_APP_SOCKET_URL || 'http://localhost:5000';

const s = {
  fab: { position: 'fixed', bottom: '24px', right: '24px', zIndex: 999, background: '#0a5c3a', color: '#fff', border: 'none', borderRadius: '50%', width: '56px', height: '56px', fontSize: '22px', cursor: 'pointer', boxShadow: '0 4px 20px rgba(10,92,58,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center' },
  window: { position: 'fixed', bottom: '90px', right: '24px', width: '320px', height: '460px', background: '#fff', borderRadius: '16px', boxShadow: '0 8px 40px rgba(0,0,0,0.15)', zIndex: 998, display: 'flex', flexDirection: 'column', overflow: 'hidden', border: '1px solid #e0e0e0' },
  header: { background: '#0a5c3a', padding: '14px 16px', display: 'flex', alignItems: 'center', gap: '10px' },
  headerTitle: { color: '#fff', fontWeight: 600, fontSize: '14px' },
  headerSub: { color: 'rgba(255,255,255,0.7)', fontSize: '11px' },
  dot: { width: '8px', height: '8px', borderRadius: '50%', background: '#7effc2' },
  messages: { flex: 1, overflowY: 'auto', padding: '12px', display: 'flex', flexDirection: 'column', gap: '8px' },
  msgIn: { alignSelf: 'flex-start', background: '#f0f7f4', padding: '8px 12px', borderRadius: '12px 12px 12px 2px', fontSize: '13px', maxWidth: '80%', color: '#1a1a1a' },
  msgOut: { alignSelf: 'flex-end', background: '#0a5c3a', color: '#fff', padding: '8px 12px', borderRadius: '12px 12px 2px 12px', fontSize: '13px', maxWidth: '80%' },
  msgTime: { fontSize: '10px', opacity: 0.6, marginTop: '2px' },
  inputRow: { padding: '12px', borderTop: '1px solid #f0f0f0', display: 'flex', gap: '8px' },
  input: { flex: 1, border: '1px solid #ddd', borderRadius: '20px', padding: '8px 14px', fontSize: '13px', outline: 'none' },
  sendBtn: { background: '#0a5c3a', color: '#fff', border: 'none', borderRadius: '50%', width: '36px', height: '36px', cursor: 'pointer', fontSize: '14px' },
  loginMsg: { padding: '1rem', textAlign: 'center', color: '#666', fontSize: '13px' },
};

export default function ChatWidget() {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [socket, setSocket] = useState(null);
  const [typing, setTyping] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    if (!user || !open) return;

    // Load chat history
    getMyChat().then(({ data }) => setMessages(data.messages || [])).catch(() => {});

    // Connect socket
    const sock = io(SOCKET_URL, { auth: { token: user.token } });
    setSocket(sock);
    sock.emit('join_chat', { userId: user._id });

    sock.on('receive_message', (msg) => {
      setMessages((prev) => [...prev, msg]);
    });

    sock.on('user_typing', () => setTyping(true));
    sock.on('user_stop_typing', () => setTyping(false));

    return () => sock.disconnect();
  }, [user, open]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMsg = () => {
    if (!input.trim() || !socket) return;
    socket.emit('send_message', {
      userId: user._id,
      text: input,
      senderName: user.name,
      isAdmin: false,
    });
    setInput('');
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') sendMsg();
    else {
      socket?.emit('typing', { userId: user._id });
      clearTimeout(window._typingTimeout);
      window._typingTimeout = setTimeout(() => socket?.emit('stop_typing', { userId: user._id }), 1500);
    }
  };

  return (
    <>
      <button style={s.fab} onClick={() => setOpen((v) => !v)} title="Chat with us">
        {open ? '✕' : '💬'}
      </button>
      {open && (
        <div style={s.window}>
          <div style={s.header}>
            <div style={s.dot} />
            <div>
              <div style={s.headerTitle}>Wynis Support</div>
              <div style={s.headerSub}>📞 9532925275 · Online</div>
            </div>
          </div>
          {!user ? (
            <div style={s.loginMsg}>
              <p style={{ fontSize: '2rem' }}>🌿</p>
              <p>Please <strong>login</strong> to chat with us!</p>
              <p style={{ marginTop: '8px', color: '#0a5c3a', fontSize: '12px' }}>Or call us at <strong>9532925275</strong></p>
            </div>
          ) : (
            <>
              <div style={s.messages}>
                {messages.length === 0 && (
                  <div style={{ textAlign: 'center', color: '#aaa', fontSize: '12px', marginTop: '1rem' }}>
                    👋 Hi {user.name}! How can we help you today?
                  </div>
                )}
                {messages.map((msg, i) => (
                  <div key={i} style={msg.isAdmin ? s.msgIn : s.msgOut}>
                    <div>{msg.text}</div>
                    <div style={s.msgTime}>{msg.isAdmin ? msg.senderName || 'Support' : 'You'} · {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                  </div>
                ))}
                {typing && <div style={{ ...s.msgIn, color: '#888', fontStyle: 'italic' }}>Support is typing...</div>}
                <div ref={messagesEndRef} />
              </div>
              <div style={s.inputRow}>
                <input
                  style={s.input}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Type a message..."
                />
                <button style={s.sendBtn} onClick={sendMsg}>➤</button>
              </div>
            </>
          )}
        </div>
      )}
    </>
  );
}
