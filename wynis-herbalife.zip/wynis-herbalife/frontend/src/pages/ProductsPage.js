import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getProducts } from '../utils/api';
import { useCart } from '../context/CartContext';
import toast from 'react-hot-toast';

const s = {
  page: { minHeight: '100vh', background: '#f8faf9', padding: '2rem' },
  header: { marginBottom: '1.5rem' },
  title: { fontSize: '1.8rem', fontWeight: 700, color: '#0a5c3a', fontFamily: 'Georgia, serif' },
  filters: { display: 'flex', gap: '12px', marginBottom: '1.5rem', flexWrap: 'wrap', alignItems: 'center' },
  input: { border: '1.5px solid #ddd', borderRadius: '8px', padding: '8px 14px', fontSize: '14px', outline: 'none', minWidth: '200px' },
  select: { border: '1.5px solid #ddd', borderRadius: '8px', padding: '8px 12px', fontSize: '14px', outline: 'none' },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: '1.25rem' },
  card: { background: '#fff', borderRadius: '12px', overflow: 'hidden', boxShadow: '0 2px 12px rgba(0,0,0,0.07)', transition: 'transform 0.2s, box-shadow 0.2s', cursor: 'pointer' },
  img: { width: '100%', height: '200px', objectFit: 'cover', background: '#e8f5ee' },
  body: { padding: '1rem' },
  name: { fontWeight: 600, fontSize: '15px', marginBottom: '4px', color: '#1a1a1a' },
  cat: { fontSize: '11px', color: '#0a5c3a', background: '#e8f5ee', padding: '2px 8px', borderRadius: '20px', display: 'inline-block', marginBottom: '8px' },
  priceRow: { display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '10px' },
  price: { fontWeight: 700, fontSize: '18px', color: '#0a5c3a' },
  origPrice: { fontSize: '13px', color: '#aaa', textDecoration: 'line-through' },
  discount: { fontSize: '12px', color: '#e74c3c', fontWeight: 600 },
  stars: { fontSize: '12px', color: '#f39c12', marginBottom: '10px' },
  addBtn: { width: '100%', background: '#0a5c3a', color: '#fff', border: 'none', borderRadius: '8px', padding: '10px', fontWeight: 600, cursor: 'pointer', fontSize: '14px' },
};

export default function ProductsPage() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [sort, setSort] = useState('');
  const { addItem } = useCart();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true);
      try {
        const { data } = await getProducts({ search, category, sort });
        setProducts(data);
      } catch {
        toast.error('Failed to load products');
      } finally {
        setLoading(false);
      }
    };
    const timer = setTimeout(fetchProducts, 300);
    return () => clearTimeout(timer);
  }, [search, category, sort]);

  const handleAddToCart = async (e, product) => {
    e.stopPropagation();
    try {
      await addItem(product);
      toast.success(`${product.name} added to cart! 🛒`);
    } catch {
      toast.error('Please login to add to cart');
    }
  };

  const getDiscount = (price, orig) => orig ? Math.round(((orig - price) / orig) * 100) : 0;

  return (
    <div style={s.page}>
      <div style={s.header}>
        <h1 style={s.title}>🌿 Our Products</h1>
        <p style={{ color: '#666', marginTop: '4px' }}>Premium Herbalife nutrition products</p>
      </div>
      <div style={s.filters}>
        <input style={s.input} placeholder="🔍 Search products..." value={search} onChange={(e) => setSearch(e.target.value)} />
        <select style={s.select} value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="">All Categories</option>
          <option value="weight-management">Weight Management</option>
          <option value="nutrition">Nutrition</option>
          <option value="energy">Energy</option>
          <option value="sports">Sports</option>
          <option value="personal-care">Personal Care</option>
        </select>
        <select style={s.select} value={sort} onChange={(e) => setSort(e.target.value)}>
          <option value="">Sort By</option>
          <option value="price-asc">Price: Low to High</option>
          <option value="price-desc">Price: High to Low</option>
          <option value="rating">Best Rated</option>
        </select>
        {loading && <span style={{ color: '#888', fontSize: '14px' }}>Loading...</span>}
      </div>
      {products.length === 0 && !loading ? (
        <div style={{ textAlign: 'center', padding: '3rem', color: '#888' }}>
          <div style={{ fontSize: '3rem' }}>🌿</div>
          <p>No products found</p>
        </div>
      ) : (
        <div style={s.grid}>
          {products.map((p) => (
            <div key={p._id} style={s.card} onClick={() => navigate(`/products/${p._id}`)}>
              <img src={p.image || 'https://via.placeholder.com/300x200/e8f5ee/0a5c3a?text=Herbalife'} alt={p.name} style={s.img} />
              <div style={s.body}>
                <span style={s.cat}>{p.category}</span>
                <div style={s.name}>{p.name}</div>
                <div style={s.stars}>{'★'.repeat(Math.round(p.rating))}{'☆'.repeat(5 - Math.round(p.rating))} <span style={{ color: '#888' }}>({p.reviews})</span></div>
                <div style={s.priceRow}>
                  <span style={s.price}>₹{p.price}</span>
                  {p.originalPrice && <span style={s.origPrice}>₹{p.originalPrice}</span>}
                  {p.originalPrice && <span style={s.discount}>{getDiscount(p.price, p.originalPrice)}% off</span>}
                </div>
                <button style={s.addBtn} onClick={(e) => handleAddToCart(e, p)}>Add to Cart 🛒</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
