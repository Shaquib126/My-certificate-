import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { createOrder, createRazorpayOrder, verifyPayment, payOrder } from '../utils/api';
import toast from 'react-hot-toast';

const s = {
  page: { minHeight: '100vh', background: '#f8faf9', padding: '2rem' },
  title: { fontSize: '1.8rem', fontWeight: 700, color: '#0a5c3a', fontFamily: 'Georgia, serif', marginBottom: '1.5rem' },
  layout: { display: 'grid', gridTemplateColumns: '1fr 320px', gap: '1.5rem', alignItems: 'start' },
  section: { background: '#fff', borderRadius: '12px', padding: '1.5rem', boxShadow: '0 1px 6px rgba(0,0,0,0.06)', marginBottom: '1rem' },
  sectionTitle: { fontWeight: 700, fontSize: '15px', marginBottom: '1rem', color: '#333' },
  row2: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' },
  label: { display: 'block', fontSize: '13px', fontWeight: 500, color: '#555', marginBottom: '4px' },
  input: { width: '100%', border: '1.5px solid #e0e0e0', borderRadius: '8px', padding: '9px 12px', fontSize: '14px', outline: 'none', boxSizing: 'border-box' },
  payMethods: { display: 'flex', gap: '10px', marginBottom: '1rem' },
  payOpt: { flex: 1, border: '2px solid #e0e0e0', borderRadius: '10px', padding: '12px', textAlign: 'center', cursor: 'pointer', fontSize: '13px', fontWeight: 500 },
  payOptActive: { borderColor: '#0a5c3a', background: '#f0f7f4', color: '#0a5c3a' },
  orderItem: { display: 'flex', justifyContent: 'space-between', fontSize: '14px', padding: '6px 0', borderBottom: '1px solid #f5f5f5' },
  total: { display: 'flex', justifyContent: 'space-between', fontWeight: 700, fontSize: '16px', paddingTop: '12px', marginTop: '4px' },
  payBtn: { width: '100%', background: '#0a5c3a', color: '#fff', border: 'none', borderRadius: '10px', padding: '14px', fontWeight: 700, fontSize: '15px', cursor: 'pointer', marginTop: '1rem' },
};

export default function CheckoutPage() {
  const { cartItems, totalPrice, clearAll } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [payMethod, setPayMethod] = useState('razorpay');
  const [loading, setLoading] = useState(false);
  const [address, setAddress] = useState({ name: user?.name || '', phone: '', street: '', city: '', state: '', pincode: '' });

  const shipping = totalPrice > 999 ? 0 : 99;
  const grandTotal = totalPrice + shipping;

  const handleRazorpay = async (orderId) => {
    const { data: rpData } = await createRazorpayOrder(grandTotal);

    return new Promise((resolve, reject) => {
      const options = {
        key: rpData.key,
        amount: rpData.amount,
        currency: 'INR',
        name: 'Wynis Herbalife',
        description: 'Health & Nutrition Products',
        order_id: rpData.orderId,
        prefill: { name: user.name, email: user.email, contact: address.phone },
        theme: { color: '#0a5c3a' },
        handler: async (response) => {
          try {
            await verifyPayment(response);
            await payOrder(orderId, response);
            resolve();
          } catch {
            reject(new Error('Payment verification failed'));
          }
        },
        modal: { ondismiss: () => reject(new Error('Payment cancelled')) },
      };

      if (window.Razorpay) {
        const rzp = new window.Razorpay(options);
        rzp.open();
      } else {
        // Load Razorpay script dynamically
        const script = document.createElement('script');
        script.src = 'https://checkout.razorpay.com/v1/checkout.js';
        script.onload = () => {
          const rzp = new window.Razorpay(options);
          rzp.open();
        };
        script.onerror = () => reject(new Error('Razorpay failed to load'));
        document.body.appendChild(script);
      }
    });
  };

  const handlePlaceOrder = async () => {
    if (!address.name || !address.phone || !address.street || !address.city || !address.pincode) {
      return toast.error('Please fill in all address fields');
    }
    setLoading(true);
    try {
      const { data: order } = await createOrder({
        items: cartItems.map((i) => ({ product: i.product, name: i.name, price: i.price, image: i.image, quantity: i.quantity })),
        shippingAddress: address,
        paymentMethod: payMethod,
        itemsPrice: totalPrice,
      });

      if (payMethod === 'razorpay' || payMethod === 'upi') {
        await handleRazorpay(order._id);
        toast.success('🎉 Payment successful! Order placed!');
      } else {
        toast.success('📦 Order placed! Pay on delivery.');
      }

      await clearAll();
      navigate(`/orders/${order._id}`);
    } catch (err) {
      toast.error(err.message || 'Order failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const upd = (field) => (e) => setAddress({ ...address, [field]: e.target.value });

  return (
    <div style={s.page}>
      <h1 style={s.title}>📦 Checkout</h1>
      <div style={s.layout}>
        <div>
          <div style={s.section}>
            <div style={s.sectionTitle}>📍 Delivery Address</div>
            <div style={s.row2}>
              <div><label style={s.label}>Full Name</label><input style={s.input} value={address.name} onChange={upd('name')} placeholder="Full Name" /></div>
              <div><label style={s.label}>Phone</label><input style={s.input} value={address.phone} onChange={upd('phone')} placeholder="9XXXXXXXXX" /></div>
            </div>
            <div style={{ marginTop: '12px' }}><label style={s.label}>Street Address</label><input style={s.input} value={address.street} onChange={upd('street')} placeholder="House no, street, area" /></div>
            <div style={{ ...s.row2, marginTop: '12px' }}>
              <div><label style={s.label}>City</label><input style={s.input} value={address.city} onChange={upd('city')} placeholder="City" /></div>
              <div><label style={s.label}>State</label><input style={s.input} value={address.state} onChange={upd('state')} placeholder="State" /></div>
            </div>
            <div style={{ marginTop: '12px', maxWidth: '200px' }}><label style={s.label}>Pincode</label><input style={s.input} value={address.pincode} onChange={upd('pincode')} placeholder="XXXXXX" /></div>
          </div>

          <div style={s.section}>
            <div style={s.sectionTitle}>💳 Payment Method</div>
            <div style={s.payMethods}>
              {[
                { id: 'razorpay', label: '💳 Razorpay', sub: 'Cards, UPI, Wallets' },
                { id: 'upi', label: '📱 UPI', sub: 'GPay, PhonePe, Paytm' },
                { id: 'cod', label: '💵 Cash', sub: 'Pay on Delivery' },
              ].map((m) => (
                <div key={m.id} style={{ ...s.payOpt, ...(payMethod === m.id ? s.payOptActive : {}) }} onClick={() => setPayMethod(m.id)}>
                  <div>{m.label}</div>
                  <div style={{ fontSize: '11px', color: '#888', marginTop: '2px' }}>{m.sub}</div>
                </div>
              ))}
            </div>
            {(payMethod === 'razorpay' || payMethod === 'upi') && (
              <div style={{ background: '#f0f7f4', borderRadius: '8px', padding: '10px 14px', fontSize: '13px', color: '#0a5c3a' }}>
                ✅ Secure payment powered by Razorpay · Supports all UPI apps
              </div>
            )}
          </div>
        </div>

        <div>
          <div style={s.section}>
            <div style={s.sectionTitle}>🧾 Order Summary</div>
            {cartItems.map((item) => (
              <div key={item.product} style={s.orderItem}>
                <span>{item.name} × {item.quantity}</span>
                <span>₹{item.price * item.quantity}</span>
              </div>
            ))}
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '14px', padding: '6px 0', color: '#555' }}>
              <span>Shipping</span>
              <span style={{ color: shipping === 0 ? '#0a5c3a' : '#555' }}>{shipping === 0 ? 'FREE' : `₹${shipping}`}</span>
            </div>
            <div style={s.total}><span>Total</span><span style={{ color: '#0a5c3a' }}>₹{grandTotal}</span></div>
            <button style={s.payBtn} onClick={handlePlaceOrder} disabled={loading || cartItems.length === 0}>
              {loading ? 'Processing...' : payMethod === 'cod' ? '📦 Place Order' : `💳 Pay ₹${grandTotal}`}
            </button>
            <p style={{ fontSize: '11px', color: '#aaa', textAlign: 'center', marginTop: '8px' }}>🔒 Secure & encrypted payment</p>
          </div>
          <div style={{ ...s.section, textAlign: 'center' }}>
            <p style={{ fontSize: '13px', color: '#666' }}>Need help?</p>
            <p style={{ fontSize: '15px', fontWeight: 700, color: '#0a5c3a' }}>📞 9532925275</p>
          </div>
        </div>
      </div>
    </div>
  );
}
