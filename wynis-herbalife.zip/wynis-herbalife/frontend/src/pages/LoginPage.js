import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { login } from '../utils/api';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

const s = {
  page: { minHeight: '100vh', background: 'linear-gradient(135deg, #f0f7f4 0%, #e8f5ee 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem' },
  card: { background: '#fff', borderRadius: '16px', padding: '2.5rem', width: '100%', maxWidth: '400px', boxShadow: '0 4px 30px rgba(10,92,58,0.1)' },
  logo: { textAlign: 'center', marginBottom: '1.5rem' },
  logoIcon: { fontSize: '2.5rem' },
  logoText: { color: '#0a5c3a', fontFamily: 'Georgia, serif', fontSize: '1.5rem', fontWeight: 700 },
  title: { fontSize: '1.4rem', fontWeight: 700, marginBottom: '0.25rem', color: '#1a1a1a' },
  sub: { color: '#888', fontSize: '0.9rem', marginBottom: '1.5rem' },
  label: { display: 'block', fontSize: '13px', fontWeight: 500, color: '#444', marginBottom: '4px' },
  input: { width: '100%', border: '1.5px solid #e0e0e0', borderRadius: '8px', padding: '10px 14px', fontSize: '15px', outline: 'none', marginBottom: '1rem', boxSizing: 'border-box', transition: 'border 0.2s' },
  btn: { width: '100%', background: '#0a5c3a', color: '#fff', border: 'none', borderRadius: '8px', padding: '12px', fontSize: '15px', fontWeight: 600, cursor: 'pointer', marginTop: '0.5rem' },
  link: { textAlign: 'center', marginTop: '1rem', fontSize: '14px', color: '#666' },
};

export default function LoginPage() {
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const { loginUser } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data } = await login(form);
      loginUser(data);
      toast.success(`Welcome back, ${data.name}! 🌿`);
      navigate('/products');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={s.page}>
      <div style={s.card}>
        <div style={s.logo}>
          <div style={s.logoIcon}>🌿</div>
          <div style={s.logoText}>Wynis Herbalife</div>
        </div>
        <h2 style={s.title}>Welcome Back</h2>
        <p style={s.sub}>Login to your account</p>
        <form onSubmit={handleSubmit}>
          <label style={s.label}>Email</label>
          <input style={s.input} type="email" placeholder="you@email.com" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
          <label style={s.label}>Password</label>
          <input style={s.input} type="password" placeholder="••••••••" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required />
          <button style={s.btn} type="submit" disabled={loading}>
            {loading ? 'Logging in...' : 'Login →'}
          </button>
        </form>
        <p style={s.link}>Don't have an account? <Link to="/signup" style={{ color: '#0a5c3a', fontWeight: 600 }}>Sign Up</Link></p>
      </div>
    </div>
  );
}
