import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { getMyOrders } from '../utils/api';

const statusColors = {
  pending: { bg: '#fff8e1', color: '#f57c00' },
  confirmed: { bg: '#e8f5ee', color: '#0a5c3a' },
  shipped: { bg: '#e3f2fd', color: '#1565c0' },
  delivered: { bg: '#f1f8e9', color: '#388e3c' },
  cancelled: { bg: '#fce4ec', color: '#c62828' },
};

export default function OrdersPage() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getMyOrders()
      .then(({ data }) => setOrders(data))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return (
    <div style={{ minHeight: '100vh', background: '#f8faf9', padding: '2rem' }}>
      <h1 style={{ fontSize: '1.8rem', fontWeight: 700, color: '#0a5c3a', fontFamily: 'Georgia, serif', marginBottom: '1.5rem' }}>📦 My Orders</h1>
      {loading && <p style={{ color: '#888' }}>Loading orders...</p>}
      {!loading && orders.length === 0 && (
        <div style={{ textAlign: 'center', padding: '4rem', color: '#888' }}>
          <div style={{ fontSize: '3rem' }}>📦</div>
          <h2>No orders yet</h2>
          <Link to="/products" style={{ color: '#0a5c3a', fontWeight: 600 }}>Start Shopping →</Link>
        </div>
      )}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        {orders.map((order) => {
          const sc = statusColors[order.status] || statusColors.pending;
          return (
            <Link key={order._id} to={`/orders/${order._id}`} style={{ textDecoration: 'none' }}>
              <div style={{ background: '#fff', borderRadius: '12px', padding: '1.25rem 1.5rem', boxShadow: '0 1px 6px rgba(0,0,0,0.06)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', transition: 'box-shadow 0.2s' }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: '14px', color: '#1a1a1a', marginBottom: '4px' }}>Order #{order._id.slice(-8).toUpperCase()}</div>
                  <div style={{ fontSize: '13px', color: '#888' }}>{order.items.length} item(s) · {new Date(order.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                  <span style={{ fontWeight: 700, color: '#0a5c3a', fontSize: '16px' }}>₹{order.totalPrice}</span>
                  <span style={{ background: sc.bg, color: sc.color, padding: '4px 12px', borderRadius: '20px', fontSize: '12px', fontWeight: 600, textTransform: 'capitalize' }}>{order.status}</span>
                </div>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
