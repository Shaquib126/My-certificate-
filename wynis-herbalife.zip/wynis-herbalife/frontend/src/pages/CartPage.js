import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import toast from 'react-hot-toast';

const s = {
  page: { minHeight: '100vh', background: '#f8faf9', padding: '2rem' },
  title: { fontSize: '1.8rem', fontWeight: 700, color: '#0a5c3a', fontFamily: 'Georgia, serif', marginBottom: '1.5rem' },
  layout: { display: 'grid', gridTemplateColumns: '1fr 320px', gap: '1.5rem', alignItems: 'start' },
  item: { background: '#fff', borderRadius: '12px', padding: '1rem', display: 'flex', gap: '1rem', alignItems: 'center', marginBottom: '10px', boxShadow: '0 1px 6px rgba(0,0,0,0.06)' },
  img: { width: '80px', height: '80px', objectFit: 'cover', borderRadius: '8px', background: '#e8f5ee' },
  name: { fontWeight: 600, fontSize: '15px', marginBottom: '4px' },
  price: { color: '#0a5c3a', fontWeight: 700, fontSize: '16px' },
  qtyRow: { display: 'flex', alignItems: 'center', gap: '10px', marginTop: '8px' },
  qtyBtn: { background: '#f0f0f0', border: 'none', borderRadius: '4px', width: '28px', height: '28px', cursor: 'pointer', fontSize: '16px', fontWeight: 700 },
  qty: { fontWeight: 600, minWidth: '20px', textAlign: 'center' },
  removeBtn: { background: 'none', border: 'none', color: '#e74c3c', cursor: 'pointer', fontSize: '13px', marginTop: '8px' },
  summary: { background: '#fff', borderRadius: '12px', padding: '1.5rem', boxShadow: '0 1px 6px rgba(0,0,0,0.06)', position: 'sticky', top: '80px' },
  summaryTitle: { fontWeight: 700, fontSize: '16px', marginBottom: '1rem' },
  row: { display: 'flex', justifyContent: 'space-between', marginBottom: '8px', fontSize: '14px', color: '#555' },
  totalRow: { display: 'flex', justifyContent: 'space-between', fontWeight: 700, fontSize: '16px', borderTop: '1px solid #eee', paddingTop: '12px', marginTop: '8px' },
  checkoutBtn: { width: '100%', background: '#0a5c3a', color: '#fff', border: 'none', borderRadius: '8px', padding: '12px', fontWeight: 700, fontSize: '15px', cursor: 'pointer', marginTop: '1rem' },
  freeShip: { color: '#0a5c3a', fontSize: '12px', textAlign: 'center', marginTop: '8px' },
  empty: { textAlign: 'center', padding: '4rem', color: '#888' },
};

export default function CartPage() {
  const { cartItems, updateItem, removeItem, totalItems, totalPrice } = useCart();
  const navigate = useNavigate();
  const shipping = totalPrice > 999 ? 0 : 99;

  if (cartItems.length === 0) {
    return (
      <div style={s.page}>
        <div style={s.empty}>
          <div style={{ fontSize: '4rem' }}>🛒</div>
          <h2>Your cart is empty</h2>
          <p style={{ marginBottom: '1.5rem' }}>Add some Herbalife products to get started!</p>
          <Link to="/products" style={{ background: '#0a5c3a', color: '#fff', padding: '10px 24px', borderRadius: '8px', textDecoration: 'none', fontWeight: 600 }}>Shop Now</Link>
        </div>
      </div>
    );
  }

  return (
    <div style={s.page}>
      <h1 style={s.title}>🛒 Your Cart ({totalItems} items)</h1>
      <div style={s.layout}>
        <div>
          {cartItems.map((item) => (
            <div key={item.product} style={s.item}>
              <img src={item.image || 'https://via.placeholder.com/80x80/e8f5ee/0a5c3a?text=H'} alt={item.name} style={s.img} />
              <div style={{ flex: 1 }}>
                <div style={s.name}>{item.name}</div>
                <div style={s.price}>₹{item.price}</div>
                <div style={s.qtyRow}>
                  <button style={s.qtyBtn} onClick={() => updateItem(item.product, item.quantity - 1)}>-</button>
                  <span style={s.qty}>{item.quantity}</span>
                  <button style={s.qtyBtn} onClick={() => updateItem(item.product, item.quantity + 1)}>+</button>
                </div>
                <button style={s.removeBtn} onClick={() => { removeItem(item.product); toast.success('Item removed'); }}>Remove ✕</button>
              </div>
              <div style={{ fontWeight: 700, color: '#0a5c3a', fontSize: '16px' }}>₹{item.price * item.quantity}</div>
            </div>
          ))}
        </div>
        <div style={s.summary}>
          <div style={s.summaryTitle}>Order Summary</div>
          <div style={s.row}><span>Items ({totalItems})</span><span>₹{totalPrice}</span></div>
          <div style={s.row}><span>Shipping</span><span style={{ color: shipping === 0 ? '#0a5c3a' : '#555' }}>{shipping === 0 ? 'FREE' : `₹${shipping}`}</span></div>
          <div style={s.totalRow}><span>Total</span><span>₹{totalPrice + shipping}</span></div>
          {shipping > 0 && <div style={s.freeShip}>Add ₹{1000 - totalPrice} more for FREE shipping</div>}
          <button style={s.checkoutBtn} onClick={() => navigate('/checkout')}>Proceed to Checkout →</button>
          <Link to="/products" style={{ display: 'block', textAlign: 'center', marginTop: '10px', color: '#0a5c3a', fontSize: '13px', textDecoration: 'none' }}>← Continue Shopping</Link>
        </div>
      </div>
    </div>
  );
}
