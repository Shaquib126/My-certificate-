import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getOrder } from '../utils/api';

const statusColors = {
  pending: '#f57c00', confirmed: '#0a5c3a', shipped: '#1565c0', delivered: '#388e3c', cancelled: '#c62828',
};

const steps = ['pending', 'confirmed', 'shipped', 'delivered'];

export default function OrderDetailPage() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);

  useEffect(() => {
    getOrder(id).then(({ data }) => setOrder(data)).catch(() => {});
  }, [id]);

  if (!order) return <div style={{ padding: '4rem', textAlign: 'center' }}>Loading...</div>;

  const stepIdx = steps.indexOf(order.status);

  return (
    <div style={{ minHeight: '100vh', background: '#f8faf9', padding: '2rem' }}>
      <Link to="/orders" style={{ color: '#0a5c3a', fontSize: '14px', textDecoration: 'none' }}>← All Orders</Link>
      <h1 style={{ fontFamily: 'Georgia, serif', fontSize: '1.6rem', fontWeight: 700, color: '#0a5c3a', margin: '1rem 0' }}>
        Order #{order._id.slice(-8).toUpperCase()}
      </h1>

      {/* Status stepper */}
      {order.status !== 'cancelled' && (
        <div style={{ background: '#fff', borderRadius: '12px', padding: '1.5rem', marginBottom: '1rem', boxShadow: '0 1px 6px rgba(0,0,0,0.06)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', position: 'relative' }}>
            <div style={{ position: 'absolute', top: '14px', left: '10%', right: '10%', height: '2px', background: '#e0e0e0', zIndex: 0 }} />
            {steps.map((step, i) => (
              <div key={step} style={{ textAlign: 'center', zIndex: 1, flex: 1 }}>
                <div style={{ width: '28px', height: '28px', borderRadius: '50%', background: i <= stepIdx ? '#0a5c3a' : '#e0e0e0', margin: '0 auto 6px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: '12px', fontWeight: 700 }}>{i < stepIdx ? '✓' : i + 1}</div>
                <div style={{ fontSize: '11px', fontWeight: i <= stepIdx ? 600 : 400, color: i <= stepIdx ? '#0a5c3a' : '#aaa', textTransform: 'capitalize' }}>{step}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: '1rem' }}>
        <div>
          <div style={{ background: '#fff', borderRadius: '12px', padding: '1.5rem', marginBottom: '1rem', boxShadow: '0 1px 6px rgba(0,0,0,0.06)' }}>
            <h3 style={{ fontWeight: 700, marginBottom: '1rem', fontSize: '15px' }}>Items Ordered</h3>
            {order.items.map((item, i) => (
              <div key={i} style={{ display: 'flex', gap: '12px', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid #f5f5f5' }}>
                <img src={item.image || 'https://via.placeholder.com/60/e8f5ee/0a5c3a?text=H'} alt={item.name} style={{ width: '60px', height: '60px', borderRadius: '8px', objectFit: 'cover' }} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 500 }}>{item.name}</div>
                  <div style={{ fontSize: '13px', color: '#888' }}>Qty: {item.quantity} × ₹{item.price}</div>
                </div>
                <div style={{ fontWeight: 700, color: '#0a5c3a' }}>₹{item.price * item.quantity}</div>
              </div>
            ))}
          </div>

          <div style={{ background: '#fff', borderRadius: '12px', padding: '1.5rem', boxShadow: '0 1px 6px rgba(0,0,0,0.06)' }}>
            <h3 style={{ fontWeight: 700, marginBottom: '0.75rem', fontSize: '15px' }}>📍 Delivery Address</h3>
            <div style={{ fontSize: '14px', color: '#555', lineHeight: 1.8 }}>
              <strong>{order.shippingAddress.name}</strong><br />
              {order.shippingAddress.phone}<br />
              {order.shippingAddress.street}, {order.shippingAddress.city}<br />
              {order.shippingAddress.state} - {order.shippingAddress.pincode}
            </div>
          </div>
        </div>

        <div>
          <div style={{ background: '#fff', borderRadius: '12px', padding: '1.5rem', boxShadow: '0 1px 6px rgba(0,0,0,0.06)' }}>
            <h3 style={{ fontWeight: 700, marginBottom: '1rem', fontSize: '15px' }}>🧾 Bill Summary</h3>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '14px', marginBottom: '6px', color: '#555' }}><span>Items Total</span><span>₹{order.itemsPrice}</span></div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '14px', marginBottom: '6px', color: '#555' }}><span>Shipping</span><span>{order.shippingPrice === 0 ? 'FREE' : `₹${order.shippingPrice}`}</span></div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 700, fontSize: '16px', borderTop: '1px solid #eee', paddingTop: '10px', marginTop: '6px' }}><span>Total</span><span style={{ color: '#0a5c3a' }}>₹{order.totalPrice}</span></div>
            <div style={{ marginTop: '12px', background: order.isPaid ? '#e8f5ee' : '#fff8e1', borderRadius: '8px', padding: '8px 12px', fontSize: '13px', fontWeight: 600, color: order.isPaid ? '#0a5c3a' : '#f57c00', textAlign: 'center' }}>
              {order.isPaid ? '✅ Payment Confirmed' : '⏳ Payment Pending'}
            </div>
            <div style={{ marginTop: '10px', textAlign: 'center', fontSize: '12px', color: '#888', textTransform: 'capitalize' }}>Payment: {order.paymentMethod}</div>
          </div>
          <div style={{ background: '#0a5c3a', borderRadius: '12px', padding: '1rem', marginTop: '12px', textAlign: 'center', color: '#fff' }}>
            <div style={{ fontSize: '13px', opacity: 0.8 }}>Need help with this order?</div>
            <a href="tel:+919532925275" style={{ color: '#7effc2', fontWeight: 700, fontSize: '15px', textDecoration: 'none' }}>📞 9532925275</a>
          </div>
        </div>
      </div>
    </div>
  );
}
