// HomePage.js
import React from 'react';
import { Link } from 'react-router-dom';

const s = {
  hero: { background: 'linear-gradient(135deg, #0a5c3a 0%, #1a7a52 60%, #2d9e6b 100%)', color: '#fff', padding: '5rem 2rem', textAlign: 'center' },
  heroTitle: { fontFamily: 'Georgia, serif', fontSize: '3rem', fontWeight: 900, marginBottom: '1rem', lineHeight: 1.2 },
  heroSub: { fontSize: '1.1rem', opacity: 0.85, maxWidth: '500px', margin: '0 auto 2rem' },
  heroBtns: { display: 'flex', gap: '12px', justifyContent: 'center', flexWrap: 'wrap' },
  btn: { background: '#7effc2', color: '#0a5c3a', padding: '12px 28px', borderRadius: '8px', fontWeight: 700, textDecoration: 'none', fontSize: '15px' },
  btn2: { background: 'transparent', color: '#fff', border: '2px solid rgba(255,255,255,0.5)', padding: '12px 28px', borderRadius: '8px', fontWeight: 600, textDecoration: 'none', fontSize: '15px' },
  features: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1.5rem', padding: '3rem 2rem', background: '#f8faf9' },
  feat: { background: '#fff', borderRadius: '12px', padding: '1.5rem', textAlign: 'center', boxShadow: '0 2px 10px rgba(0,0,0,0.06)' },
  featIcon: { fontSize: '2rem', marginBottom: '0.75rem' },
  featTitle: { fontWeight: 700, marginBottom: '6px' },
  contact: { background: '#0a5c3a', color: '#fff', padding: '3rem 2rem', textAlign: 'center' },
};

export default function HomePage() {
  return (
    <div>
      <div style={s.hero}>
        <h1 style={s.heroTitle}>🌿 Wynis Herbalife<br /><span style={{ color: '#7effc2' }}>Your Wellness Partner</span></h1>
        <p style={s.heroSub}>Premium Herbalife nutrition products delivered to your doorstep. Start your health journey today!</p>
        <div style={s.heroBtns}>
          <Link to="/products" style={s.btn}>Shop Now →</Link>
          <Link to="/signup" style={s.btn2}>Create Account</Link>
        </div>
      </div>
      <div style={s.features}>
        {[
          { icon: '🥤', title: 'Meal Replacements', desc: 'Nutritious Formula 1 shakes for weight management' },
          { icon: '💪', title: 'Sports Nutrition', desc: 'High-protein products for active lifestyles' },
          { icon: '⚡', title: 'Energy Boosters', desc: 'Natural energy drinks and supplements' },
          { icon: '🌱', title: '100% Genuine', desc: 'Authentic Herbalife products guaranteed' },
          { icon: '🚚', title: 'Fast Delivery', desc: 'Free shipping on orders above ₹999' },
          { icon: '💬', title: '24/7 Support', desc: 'Live chat + call at 9532925275' },
        ].map((f) => (
          <div key={f.title} style={s.feat}>
            <div style={s.featIcon}>{f.icon}</div>
            <div style={s.featTitle}>{f.title}</div>
            <div style={{ fontSize: '13px', color: '#888' }}>{f.desc}</div>
          </div>
        ))}
      </div>
      <div style={s.contact}>
        <h2 style={{ fontFamily: 'Georgia, serif', marginBottom: '0.5rem' }}>Need Guidance?</h2>
        <p style={{ opacity: 0.8, marginBottom: '1rem' }}>Our wellness experts are here to help you choose the right products</p>
        <a href="tel:+919532925275" style={{ color: '#7effc2', fontSize: '1.5rem', fontWeight: 700, textDecoration: 'none' }}>📞 9532925275</a>
      </div>
    </div>
  );
}
