// ProductDetailPage.js
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getProduct } from '../utils/api';
import { useCart } from '../context/CartContext';
import toast from 'react-hot-toast';

export function ProductDetailPage() {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [qty, setQty] = useState(1);
  const { addItem } = useCart();
  const navigate = useNavigate();

  useEffect(() => {
    getProduct(id).then(({ data }) => setProduct(data)).catch(() => toast.error('Product not found'));
  }, [id]);

  if (!product) return <div style={{ padding: '4rem', textAlign: 'center' }}>Loading...</div>;

  const handleAdd = async () => {
    try { await addItem(product, qty); toast.success('Added to cart! 🛒'); }
    catch { toast.error('Please login to add to cart'); }
  };

  return (
    <div style={{ minHeight: '100vh', background: '#f8faf9', padding: '2rem' }}>
      <button onClick={() => navigate(-1)} style={{ background: 'none', border: 'none', color: '#0a5c3a', cursor: 'pointer', fontSize: '14px', marginBottom: '1rem' }}>← Back</button>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem', background: '#fff', borderRadius: '16px', padding: '2rem', boxShadow: '0 2px 12px rgba(0,0,0,0.07)' }}>
        <img src={product.image || 'https://via.placeholder.com/400x400/e8f5ee/0a5c3a?text=Herbalife'} alt={product.name} style={{ width: '100%', borderRadius: '12px', objectFit: 'cover' }} />
        <div>
          <span style={{ background: '#e8f5ee', color: '#0a5c3a', padding: '3px 10px', borderRadius: '20px', fontSize: '12px', fontWeight: 500 }}>{product.category}</span>
          <h1 style={{ fontFamily: 'Georgia, serif', fontSize: '1.8rem', margin: '12px 0', color: '#1a1a1a' }}>{product.name}</h1>
          <div style={{ color: '#f39c12', marginBottom: '8px' }}>{'★'.repeat(Math.round(product.rating))} <span style={{ color: '#888', fontSize: '13px' }}>({product.reviews} reviews)</span></div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '1rem' }}>
            <span style={{ fontSize: '2rem', fontWeight: 700, color: '#0a5c3a' }}>₹{product.price}</span>
            {product.originalPrice && <span style={{ textDecoration: 'line-through', color: '#aaa' }}>₹{product.originalPrice}</span>}
          </div>
          <p style={{ color: '#555', lineHeight: 1.7, marginBottom: '1.5rem' }}>{product.description}</p>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '1rem' }}>
            <span style={{ fontSize: '14px', fontWeight: 500 }}>Qty:</span>
            <button onClick={() => setQty(Math.max(1, qty - 1))} style={{ width: '32px', height: '32px', borderRadius: '6px', border: '1px solid #ddd', cursor: 'pointer', background: '#f5f5f5' }}>-</button>
            <span style={{ fontWeight: 700 }}>{qty}</span>
            <button onClick={() => setQty(qty + 1)} style={{ width: '32px', height: '32px', borderRadius: '6px', border: '1px solid #ddd', cursor: 'pointer', background: '#f5f5f5' }}>+</button>
          </div>
          <button onClick={handleAdd} style={{ width: '100%', background: '#0a5c3a', color: '#fff', border: 'none', borderRadius: '10px', padding: '14px', fontSize: '15px', fontWeight: 700, cursor: 'pointer' }}>Add to Cart 🛒</button>
        </div>
      </div>
    </div>
  );
}

export default ProductDetailPage;

function ProductDetailPage() { return <ProductDetailPage />; }
