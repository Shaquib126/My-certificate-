import React, { createContext, useContext, useState, useEffect } from 'react';
import { getCart, addToCart, updateCart, removeFromCart, clearCart } from '../utils/api';
import { useAuth } from './AuthContext';

const CartContext = createContext();

export const CartProvider = ({ children }) => {
  const { user } = useAuth();
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchCart = async () => {
    if (!user) return setCartItems([]);
    try {
      const { data } = await getCart();
      setCartItems(data.items || []);
    } catch {
      setCartItems([]);
    }
  };

  useEffect(() => {
    fetchCart();
  }, [user]);

  const addItem = async (product, quantity = 1) => {
    setLoading(true);
    try {
      await addToCart({
        productId: product._id,
        name: product.name,
        price: product.price,
        image: product.image,
        quantity,
      });
      await fetchCart();
    } finally {
      setLoading(false);
    }
  };

  const updateItem = async (productId, quantity) => {
    await updateCart({ productId, quantity });
    await fetchCart();
  };

  const removeItem = async (productId) => {
    await removeFromCart(productId);
    await fetchCart();
  };

  const clearAll = async () => {
    await clearCart();
    setCartItems([]);
  };

  const totalItems = cartItems.reduce((sum, i) => sum + i.quantity, 0);
  const totalPrice = cartItems.reduce((sum, i) => sum + i.price * i.quantity, 0);

  return (
    <CartContext.Provider value={{ cartItems, loading, addItem, updateItem, removeItem, clearAll, totalItems, totalPrice, fetchCart }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => useContext(CartContext);
